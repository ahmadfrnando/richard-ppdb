<?php $__env->startSection('nav__item-siswa', 'active'); ?>





<?php echo $__env->make('layouts.components.siswa._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.components.siswa._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('main'); ?>
<main>
  <div class="container-lg d-flex justify-content-center py-4">
    <div class="col-12 col-md-10 col-lg-8 p-0">
      <div class="alert alert-info py-3" role="alert">
        <h4 class="alert-heading text-dark">Selamat Datang, <?php echo e($siswa->nama); ?> !</h4>
        <p>Terima kasih telah mendaftar di SMA Swasta Katolik Mariana, silahkan tunggu konfirmasi dari admin untuk berkas pendaftaran anda. Cek pengumuman untuk informasi lebih lanjut.</p>
        <hr>
        <p class="mb-0">Pastikan anda sudah mengunduh bukti pendaftaran anda.</p>
      </div>
      <div class="row mb-4">
        <div class="col-12 col-sm-12">
          <div class="card bg-primary mb-3">
            <div class="card-body">
              <h5 class="card-title text-light font-weight-medium">Pengumuman</h5>
              <p class="card-text text-light">Lihat hasil pengumuman <?php if($pengumuman->count() > 0 || $pesan->count() > 0): ?><span class="text-success">(Tersedia)</span><?php else: ?><span class="text-danger">(belum ada)</span><?php endif; ?></p>
              <div class="text-right">
                <a href="/siswa/pengumuman" class="btn btn-light">Buka</a>
              </div>
            </div>
          </div>
        </div>
        <!-- <div class="col-12 col-sm-6">
          <div class="card bg-warning mb-3">
            <div class="card-body">
              <h5 class="card-title text-light font-weight-medium">Daftar Ulang</h5>
              <p class="card-text text-light">Lakukan pendaftaran ulang jika anda dinyatakan lulus oleh admin</p>
              <div class="text-right">
                <a href="/siswa/daftar-ulang" class="btn btn-light">Buka</a>
              </div>
            </div>
          </div>
        </div> -->
      </div>
      <div class="text-center">
        <a href="<?php echo e(route('logout')); ?>" class="btn btn-danger">Keluar</a>
      </div>
    </div>
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/fernando/Sites/richard/resources/views//pages/siswa/index.blade.php ENDPATH**/ ?>