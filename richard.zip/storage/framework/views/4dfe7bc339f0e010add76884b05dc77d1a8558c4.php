<?php echo $__env->make('layouts.components.app._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.components.app._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('main'); ?>
<main>
  <div class="container-lg">
    <div class="row justify-content-center py-4">
      <div class="col-12 col-lg-9 px-0 px-md-3 mb-4">
        <div class="mb-md-3 px-3 px-md-5 py-4 py-md-5">
          <img src="<?php echo e(asset('images/gedung-mutuharjo.jpg')); ?>" class="img-fluid mb-3" alt="...">
          <a href="<?php echo e(route('pendaftaran')); ?>" class="btn btn-primary py-2 w-100">Mulai Pendaftaran</a>
        </div>
      </div>

      <?php echo $__env->make('layouts.components.app._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/fernando/Sites/richard/resources/views//pages/index.blade.php ENDPATH**/ ?>