<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Dashboard PPDB SMA SWASTA KATOLIK MARIANA</title>
  <link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/css/all.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/css/components.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap-datepicker.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/css/admin.css')); ?>">
</head>

<body>

  <div id="app" class="">
    <section class="section">
      <div class="container mt-5">
        <div class="row">
          <div class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-4">
            <div class="login-brand">
              <img src="<?php echo e(asset('/images/logo-ppdb.svg')); ?>" alt="logo" width="128">
            </div>

            <div class="card card-primary">
              <div class="card-header">
                <h4>Login</h4>
              </div>

              <div class="card-body">
                <form method="POST" action="<?php echo e(route('login.store')); ?>">
                  <?php echo csrf_field(); ?>
                  <div class="form-group">
                    <label for="username">Username</label>
                    <input id="username" type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                      name="username" tabindex="1" required autofocus>
                  </div>

                  <div class="form-group">
                    <label for="password" class="control-label">Password</label>
                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                      name="password" tabindex="2" required>
                  </div>

                  <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-lg btn-block" tabindex="3">
                      Login
                    </button>
                  </div>
                </form>
              </div>
            </div>

            <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert">
              <?php echo e(session('error')); ?>

            </div>
            <?php endif; ?>

          </div>
        </div>
      </div>
    </section>
  </div>

  <script src="<?php echo e(asset('/js/jquery-3.3.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/popper.min.js')); ?>">
  </script>
  <script src="<?php echo e(asset('/js/bootstrap.min.js')); ?>">
  </script>
  <script src="<?php echo e(asset('/js/jquery.nicescroll.min.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/moment.min.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/stisla.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/scripts.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/custom.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/dataTables.bootstrap4.min.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/bootstrap-datepicker.min.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/bootstrap-multiselect.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/chart.js')); ?>"></script>

</body>

</html><?php /**PATH /Users/fernando/Sites/richard/resources/views/pages/auth/login.blade.php ENDPATH**/ ?>