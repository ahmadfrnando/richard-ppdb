<?php $__env->startSection('nav__item-pendaftaran', 'active'); ?>
<?php $__env->startSection('nav__icon-pendaftaran', 'opacity-100'); ?>





<?php echo $__env->make('layouts.components.app._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.components.app._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('main'); ?>
<main>
  <div class="container-lg py-4">
    <div class="row justify-content-center">
      <div class="col-12 col-lg-9 px-0 px-md-3 py-2">
        <div class="mb-md-3 px-3 px-md-5 py-4 py-md-5 bg-primary shadow-sm">
          <h4 class="text-white mb-0">Formulir Pendaftaran PPDB</h4>
          <h4 class="text-white">SMA Swasta Katolik Mariana</h4>
          <h6 class="text-white font-weight-normal">TAHUN PELAJARAN 2024/2025</h6>
        </div>
        <div class="mb-3 px-3 px-md-5 py-4 py-md-5 bg-light shadow-sm">
          <form action="<?php echo e(route('pendaftaran.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            
            <div class="siswa__section mb-4">
              <div class="d-flex align-items-center pb-3">
                <span class="bg-primary mb-2 rounded-pill" style="height: 0.4rem; width: 1.6rem;"></span>
                <h5 class="ml-3">Data Pribadi</h5>
              </div>
              <div class="form-group row">
                <label for="nama" class="col-sm-4 col-form-label font-weight-normal">Nama Pendaftar<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama" name="nama"
                    autocomplete="off" required>
                  <small class="form-text text-muted">ex: <span class="text-dark">Richard Clooney Sitinjak</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="nisn" class="col-sm-4 col-form-label font-weight-normal">NISN<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="number" class="form-control <?php $__errorArgs = ['nisn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nisn" name="nisn"
                    autocomplete="off" required>
                  <small class="form-text text-muted">ex: <span class="text-dark">188718890</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="tempat_lahir" class="col-sm-4 col-form-label font-weight-normal">Tempat Lahir<span
                    class="text-danger">*</span> </label>
                <div class="col-sm-8">
                  <input type="text" class="form-control <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tempat_lahir"
                    name="tempat_lahir" autocomplete="off" required>
                  <small class="form-text text-muted">ex: <span class="text-dark">Medan</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="tanggal_lahir" class="col-sm-4 col-form-label font-weight-normal">Tanggal Lahir<span
                    class="text-danger">*</span> </label>
                <div class="col-sm-8">
                  <div class="d-flex">
                    <input type="text" class="form-control datepicker  <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                      id="tanggal_lahir" name="tanggal_lahir" autocomplete="off" required>
                    <span class="position-absolute right-0" style="right: 1.6rem; top: 0.6rem;">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor"
                        class="bi bi-calendar" viewBox="0 0 16 16">
                        <path
                          d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM1 4v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4H1z" />
                      </svg>
                    </span>
                  </div>
                  <small class="form-text text-muted">ex: <span class="text-dark">30-08-2004</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="jenis_kelamin" class="col-sm-4 col-form-label font-weight-normal">Jenis Kelamin<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <div class="d-flex py-2">
                    <div class="form-check mr-2">
                      <input type="radio" class="form-check-input <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="jenis_kelamin-L" name="jenis_kelamin" value="L" autocomplete="off" required>
                      <label class="form-check-label" for="jenis_kelamin-L">
                        Laki - Laki
                      </label>
                    </div>
                    <div class="form-check mr-2">
                      <input type="radio" class="form-check-input <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="jenis_kelamin-P" name="jenis_kelamin" value="P" autocomplete="off" required>
                      <label class="form-check-label" for="jenis_kelamin-P">
                        Perempuan
                      </label>
                    </div>
                  </div>
                </div>
              </div>
              <div class="form-group row">
                <label for="alamat" class="col-sm-4 col-form-label font-weight-normal">Alamat Rumah<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <textarea class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alamat" name="alamat"
                    rows="3" autocomplete="off" required></textarea>
                </div>
              </div>
              <div class="form-group row">
                <label for="nomor_hp" class="col-sm-4 col-form-label font-weight-normal">Nomor HP<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="text" class="form-control <?php $__errorArgs = ['nomor_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nomor_hp"
                    name="nomor_hp" autocomplete="off" required>
                  <small class="form-text text-muted">ex: <span class="text-dark">08123456789</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="agama" class="col-sm-4 col-form-label font-weight-normal">Agama<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <select type="text" class="form-control <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="agama" name="agama"
                    autocomplete="off" required>
                    <option value="">Pilih Agama</option>
                    <option value="Islam">Islam</option>
                    <option value="Protestan">Protestan</option>
                    <option value="Katolik">Katolik</option>
                    <option value="Hindu">Hindu</option>
                    <option value="Buddha">Buddha</option>
                    </select>
                </div>
              </div>
              <div class="form-group row">
                <label for="asal_sekolah" class="col-sm-4 col-form-label font-weight-normal">Asal Sekolah<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="text" class="form-control <?php $__errorArgs = ['asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="asal_sekolah"
                    name="asal_sekolah" autocomplete="off" required>
                  <small class="form-text text-muted">ex: <span class="text-dark">SMP N 1 Medan</span></small>
                </div>
              </div>
            </div>

            
            <div class="orang__tua-section mb-4">
              <div class="d-flex align-items-center pb-3">
                <span class="bg-primary mb-2 rounded-pill" style="height: 0.4rem; width: 1.6rem;"></span>
                <h5 class="ml-3">Data Orang Tua</h5>
              </div>
              <div class="form-group row">
                <label for="nama_ayah" class="col-sm-4 col-form-label font-weight-normal">Nama Ayah<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="text" class="form-control <?php $__errorArgs = ['nama_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_ayah"
                    name="nama_ayah" autocomplete="off" required>
                  <small class="form-text text-muted">ex: <span class="text-dark">Suparjo</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="umur_ayah" class="col-sm-4 col-form-label font-weight-normal">Umur Ayah<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="number" class="form-control <?php $__errorArgs = ['umur_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="umur_ayah"
                    name="umur_ayah" autocomplete="off" required>
                  <small class="form-text text-muted">ex: <span class="text-dark">19</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="pendidikan_ayah" class="col-sm-4 col-form-label font-weight-normal">Pendidikan Ayah<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <select class="form-control <?php $__errorArgs = ['pendidikan_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pendidikan_ayah"
                    name="pendidikan_ayah" autocomplete="off" required>
                    <option value="">-- Pilih Pendidikan Ayah --</option>
                    <option value="SD">SD</option>
                    <option value="SMP">SMP</option>
                    <option value="SLTA">SLTA</option>
                    <option value="Sarjana">Sarjana</option>
                  </select>
                  <small class="form-text text-muted">nb: <span class="text-dark">( Pilih pendidikan seorang ayah
                      )</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="pekerjaan_ayah" class="col-sm-4 col-form-label font-weight-normal">Pekerjaan Ayah<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <select class="form-control <?php $__errorArgs = ['pekerjaan_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pekerjaan_ayah"
                    name="pekerjaan_ayah" autocomplete="off" required>
                    <option value="">-- Pilih Pekerjaan Ayah --</option>
                    <option value="Wiraswasta">Wiraswasta</option>
                    <option value="PNS">PNS</option>
                    <option value="Pegawai Swasta">Pegawai Swasta</option>
                    <option value="Petani">Petani</option>
                    <option value="Nelayan">Nelayan</option>
                    <option value="Buruh">Buruh</option>
                    <option value="Guru">Guru</option>
                    <option value="Dosen">Dosen</option>
                  </select>
                  <small class="form-text text-muted">nb: <span class="text-dark">( Pilih pekerjaan seorang ayah
                      )</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="nama_ibu" class="col-sm-4 col-form-label font-weight-normal">Nama Ibu<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="text" class="form-control <?php $__errorArgs = ['nama_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_ibu"
                    name="nama_ibu" autocomplete="off" required>
                  <small class="form-text text-muted">ex: <span class="text-dark">Ekowati</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="umur_ibu" class="col-sm-4 col-form-label font-weight-normal">Umur Ibu<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="number" class="form-control <?php $__errorArgs = ['umur_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="umur_ibu"
                    name="umur_ibu" autocomplete="off" required>
                  <small class="form-text text-muted">ex: <span class="text-dark">30</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="pendidikan_ibu" class="col-sm-4 col-form-label font-weight-normal">Pendidikan Ibu<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <select class="form-control <?php $__errorArgs = ['pendidikan_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pendidikan_ibu"
                    name="pendidikan_ibu" autocomplete="off" required>
                    <option value="">-- Pilih Pendidikan Ibu --</option>
                    <option value="SD">SD</option>
                    <option value="SMP">SMP</option>
                    <option value="SLTA">SLTA</option>
                    <option value="Sarjana">Sarjana</option>
                  </select>
                  <small class="form-text text-muted">nb: <span class="text-dark">( Pilih pendidikan seorang ibu
                      )</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="pekerjaan_ibu" class="col-sm-4 col-form-label font-weight-normal">Pekerjaan Ibu<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <select class="form-control <?php $__errorArgs = ['pekerjaan_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pekerjaan_ibu"
                    name="pekerjaan_ibu" autocomplete="off" required>
                    <option value="">-- Pilih Pekerjaan Ibu --</option>
                    <option value="Ibu Rumah Tangga">Ibu Rumah Tangga</option>
                    <option value="Wiraswasta">Wiraswasta</option>
                    <option value="PNS">PNS</option>
                    <option value="Pegawai Swasta">Pegawai Swasta</option>
                    <option value="Petani">Petani</option>
                    <option value="Nelayan">Nelayan</option>
                    <option value="Buruh">Buruh</option>
                    <option value="Guru">Guru</option>
                    <option value="Dosen">Dosen</option>
                  </select>
                  <small class="form-text text-muted">nb: <span class="text-dark">( Pilih pekerjaan seorang ibu
                      )</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="nomor_hp_ortu" class="col-sm-4 col-form-label font-weight-normal">Nomor HP Orang Tua<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="number" class="form-control <?php $__errorArgs = ['nomor_hp_ortu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="nomor_hp_ortu" name="nomor_hp_ortu" autocomplete="off" required>
                  <small class="form-text text-muted">ex: <span class="text-dark">08123456789</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="alamat_orang_tua" class="col-sm-4 col-form-label font-weight-normal">Alamat Rumah Orang
                  Tua<span class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <textarea class="form-control <?php $__errorArgs = ['alamat_orang_tua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alamat_orang_tua"
                    name="alamat_orang_tua" rows="3" autocomplete="off" required></textarea>
                </div>
              </div>
            </div>

            
            <div class="siswa__section mb-4">
              <div class="d-flex align-items-center pb-3">
                <span class="bg-primary mb-2 rounded-pill" style="height: 0.4rem; width: 1.6rem;"></span>
                <h5 class="ml-3">Data Tambahan</h5>
              </div>
              <div class="form-group row">
                <label for="nilai_skhu" class="col-sm-4 col-form-label font-weight-normal">Nilai SKHU<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" id="nilai_skhu" name="nilai_skhu" autocomplete="off" required>
                  <small class="form-text text-muted">ex: <span class="text-dark">8.9</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="rata_rata_skhu" class="col-sm-4 col-form-label font-weight-normal">Nilai Rata - Rata SKHU<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="number" class="form-control" id="rata_rata_skhu" name="rata_rata_skhu" autocomplete="off" required>
                  <small class="form-text text-muted">ex: <span class="text-dark">8</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="nomor_ijazah" class="col-sm-4 col-form-label font-weight-normal">Nomor Ijazah<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" id="nomor_ijazah" name="nomor_ijazah" autocomplete="off">
                  <small class="form-text text-muted">ex: <span class="text-dark">NK-299018798</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="nilai_ijazah" class="col-sm-4 col-form-label font-weight-normal">Nilai Ijazah<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="number" class="form-control" id="nilai_ijazah" name="nilai_ijazah" autocomplete="off">
                  <small class="form-text text-muted">ex: <span class="text-dark">19</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="rata_rata_ijazah" class="col-sm-4 col-form-label font-weight-normal">Nilai Rata - Rata Ijazah<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" id="rata_rata_ijazah" name="rata_rata_ijazah" autocomplete="off">
                  <small class="form-text text-muted">ex: <span class="text-dark">8.8</span></small>
                </div>
              </div>
            </div>
            
            <div class="kirim__section">
              <div class="mb-4">
                <h6 class="font-weight-semibold">PERHATIAN :</h6>
                <small class="m-0 d-block">- Isian dengan tanda (<span class="text-danger">*</span>) adalah wajib
                  diisi.</small>
                <small class="m-0 d-block">- Silahkan cek kembali seluruh data yang sudah diisi.</small>
                <small class="m-0 d-block">- Dengan mengirim data ini, saya menyatakan sudah mengisi data dengan
                  benar dan
                  lengkap.</small>
              </div>
              <button type="submit" class="btn btn-success py-2 w-100">Kirim Formulir Pendaftaran</button>
            </div>
          </form>
        </div>
      </div>
      <?php echo $__env->make('layouts.components.app._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/fernando/Sites/richard/resources/views//pages/pendaftaran.blade.php ENDPATH**/ ?>