<?php $__env->startSection('nav__item-admin-konfirmasi', 'active'); ?>

<?php $__env->startSection('title', 'Konfirmasi'); ?>

<?php $__env->startSection('content'); ?>
  <div class="card">
    <div class="card-header bg-primary text-white">
      <h3>Detail Pendaftaran Siswa</h3>
    </div>
    <div class="card-body">
      <table class="table table-striped">
        <tr>
          <th>Nomor Pendaftaran</th>
          <td><?php echo e($konfirmasi->nomor_pendaftar); ?></td>
        </tr>
        <tr>
          <th>Nama</th>
          <td><?php echo e($konfirmasi->nama); ?></td>
        </tr>
        <tr>
          <th>NISN</th>
          <td><?php echo e($konfirmasi->nisn); ?></td>
        </tr>
        <tr>
          <th>Tempat Lahir</th>
          <td><?php echo e($konfirmasi->tempat_lahir); ?></td>
        </tr>
        <tr>
          <th>Tanggal Lahir</th>
          <td><?php echo e($konfirmasi->tanggal_lahir); ?></td>
        </tr>
        <tr>
          <th>Jenis Kelamin</th>
          <td><?php echo e($konfirmasi->jenis_kelamin); ?></td>
        </tr>
        <tr>
          <th>Alamat</th>
          <td><?php echo e($konfirmasi->alamat); ?></td>
        </tr>
        <tr>
          <th>Asal Sekolah</th>
          <td><?php echo e($konfirmasi->asal_sekolah); ?></td>
        </tr>
        <tr>
          <th>Nomor HP</th>
          <td><?php echo e($konfirmasi->nomor_hp); ?></td>
        </tr>
        <tr>
          <th>Agama</th>
          <td><?php echo e($konfirmasi->agama); ?></td>
        </tr>
        <tr>
          <th>Nama Ayah</th>
          <td><?php echo e($konfirmasi->nama_ayah); ?></td>
        </tr>
        <tr>
          <th>Umur Ayah</th>
          <td><?php echo e($konfirmasi->umur_ayah); ?></td>
        </tr>
        <tr>
          <th>Pekerjaan Ayah</th>
          <td><?php echo e($konfirmasi->pekerjaan_ayah); ?></td>
        </tr>
        <tr>
          <th>Pendidikan Ayah</th>
          <td><?php echo e($konfirmasi->pendidikan_ayah); ?></td>
        </tr>
        <tr>
          <th>Nama Ibu</th>
          <td><?php echo e($konfirmasi->nama_ibu); ?></td>
        </tr>
        <tr>
          <th>Umur Ibu</th>
          <td><?php echo e($konfirmasi->umur_ibu); ?></td>
        </tr>
        <tr>
          <th>Pekerjaan Ibu</th>
          <td><?php echo e($konfirmasi->pekerjaan_ibu); ?></td>
        </tr>
        <tr>
          <th>Pendidikan Ibu</th>
          <td><?php echo e($konfirmasi->pendidikan_ibu); ?></td>
        </tr>
        <tr>
          <th>Alamat Orang Tua</th>
          <td><?php echo e($konfirmasi->alamat_orang_tua); ?></td>
        </tr>
        <tr>
          <th>Nomor HP Orang Tua</th>
          <td><?php echo e($konfirmasi->nomor_hp_ortu); ?></td>
        </tr>
        <tr>
          <th>Nilai SKHU</th>
          <td><?php echo e($konfirmasi->nilai_skhu); ?></td>
        </tr>
        <tr>
          <th>Nomor Ijazah</th>
          <td><?php echo e($konfirmasi->nomor_ijazah); ?></td>
        </tr>
        <tr>
          <th>Nilai Ijazah</th>
          <td><?php echo e($konfirmasi->nilai_ijazah); ?></td>
        </tr>
        <tr>
          <th>Status</th>
          <td><?php echo e($konfirmasi->status); ?></td>
        </tr>
      </table>
      <div class="text-center mt-4">
        <a href="<?php echo e(url('/admin/konfirmasi')); ?>" class="btn btn-secondary">Kembali</a>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/fernando/Sites/richard/resources/views/pages/admin/konfirmasi/detail.blade.php ENDPATH**/ ?>