<?php $__env->startSection('nav__item-galeri', 'active'); ?>
<?php $__env->startSection('nav__icon-galeri', 'opacity-100'); ?>




<?php echo $__env->make('layouts.components.guest._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.components.guest._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('main'); ?>
<style>
  .hero-section {
    background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),
    url('<?php echo e(asset("images/foto2.jpeg")); ?>') center/cover no-repeat;
    color: white;
    text-align: center;
    padding: 100px 20px;
  }

  .gallery-section {
    text-align: center;
    padding: 60px 20px;
  }

  .gallery-section h1 {
    color: #007bff;
    font-weight: bold;
    margin-bottom: 30px;
  }

  .gallery-item {
    margin-bottom: 30px;
    overflow: hidden;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s, box-shadow 0.3s;
  }

  .gallery-item:hover {
    transform: scale(1.05);
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
  }

  .gallery-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
  }

  .gallery-item-title {
    margin-top: 10px;
    font-size: 1.25rem;
    font-weight: bold;
    color: #555;
  }
</style>

<main style="margin-bottom: 200px">
  <div class="hero-section">
    <h1 class="text-light">Galeri Sekolah</h1>
  </div>
  <div class="gallery-section">
    <div class="container-lg">
      <div class="row">
        <?php $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 gallery-item">
          <img src="<?php echo e(asset('storage/'. $item->foto)); ?>" alt="<?php echo e($item->judul); ?>" loading="lazy">
          <div class="gallery-item-title"><?php echo e($item->judul); ?></div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>

  <?php echo $__env->make('layouts.components.guest._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/fernando/Sites/richard/resources/views/pages/guest/galeri.blade.php ENDPATH**/ ?>