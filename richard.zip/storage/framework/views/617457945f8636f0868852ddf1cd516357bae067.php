<table>
  <thead>
    <tr>
      <th><b>NOMER PENDAFTARAN</b></th>
      <th><b>NAMA</b></th>
      <th><b>TEMPAT LAHIR</b></th>
      <th><b>TANGGAL LAHIR</b></th>
      <th><b>JENIS KELAMIN</b></th>
      <th><b>ALAMAT</b></th>
      <th><b>AGAMA</b></th>
      <th><b>NOMOR HP</b></th>
      <th><b>NISN</b></th>
      <th><b>ASAL SEKOLAH</b></th>
      <th><b>NAMA AYAH</b></th>
      <th><b>UMUR AYAH</b></th>
      <th><b>PENDIDIKAN AYAH</b></th>
      <th><b>PEKERJAAN AYAH</b></th>
      <th><b>NAMA IBU</b></th>
      <th><b>UMUR IBU</b></th>
      <th><b>PENDIDIKAN IBU</b></th>
      <th><b>PEKERJAAN IBU</b></th>
      <th><b>NOMOR HP ORTU</b></th>
      <th><b>ALAMAT ORTU</b></th>
      <th><b>NILAI SKHU</b></th>
      <th><b>RATA - RATA SKHU</b></th>
      <th><b>NOMOR IJAZAH</b></th>
      <th><b>RATA - RATA NILAI IJAZAH</b></th>
      <th><b>NILAI IJAZAH</b></th>
      <th><b>STATUS PENDAFTARAN</b></th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($data->nomor_pendaftaran); ?></td>
      <td><?php echo e($data->nama); ?></td>
      <td><?php echo e($data->tempat_lahir); ?></td>
      <td><?php echo e($data->tanggal_lahir); ?></td>
      <td><?php echo e($data->jenis_kelamin); ?></td>
      <td><?php echo e($data->alamat); ?></td>
      <td><?php echo e($data->agama); ?></td>
      <td><?php echo e($data->nomor_hp); ?></td>
      <td><?php echo e($data->nisn); ?></td>
      <td><?php echo e($data->asal_sekolah); ?></td>
      <td><?php echo e($data->nama_ayah); ?></td>
      <td><?php echo e($data->umur_ayah); ?></td>
      <td><?php echo e($data->pendidikan_ayah); ?></td>
      <td><?php echo e($data->pekerjaan_ayah); ?></td>
      <td><?php echo e($data->nama_ibu); ?></td>
      <td><?php echo e($data->umur_ibu); ?></td>
      <td><?php echo e($data->pendidikan_ibu); ?></td>
      <td><?php echo e($data->pekerjaan_ibu); ?></td>
      <td><?php echo e($data->nomor_hp_ortu); ?></td>
      <td><?php echo e($data->alamat_orang_tua); ?></td>
      <td><?php echo e($data->nilai_skhu); ?></td>
      <td><?php echo e($data->rata_rata_skhu); ?></td>
      <td><?php echo e($data->nomor_ijazah); ?></td>
      <td><?php echo e($data->nilai_ijazah); ?></td>
      <td><?php echo e($data->rata_rata_ijazah); ?></td>
      <td><?php echo e($data->status == 1 ? 'Sudah Diverifikasi' : 'Belum Diverifikasi'); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table><?php /**PATH /Users/fernando/Sites/richard/resources/views/pages/admin/siswa/table.blade.php ENDPATH**/ ?>