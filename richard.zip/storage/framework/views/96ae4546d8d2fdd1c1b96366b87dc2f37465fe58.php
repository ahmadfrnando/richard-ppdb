<?php $__env->startSection('nav__item-admin', 'active'); ?>

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg- col-sm-6 col-12">
    <div class="card card-statistic-1">
      <div class="card-icon bg-primary">
        <i class="far fa-user"></i>
      </div>
      <div class="card-wrap">
        <div class="card-header">
          <h4>Total Pendaftar</h4>
        </div>
        <div class="card-body">
          <?php echo e($siswa->count()); ?>

        </div>
      </div>
    </div>
  </div>
  <div class="col-lg- col-sm-6 col-12">
    <div class="card card-statistic-1">
      <div class="card-icon bg-info">
        <i class="far fa-user"></i>
      </div>
      <div class="card-wrap">
        <div class="card-header">
          <h4>Total Pengumuman</h4>
        </div>
        <div class="card-body">
          <?php echo e($pengumuman->count()); ?>

        </div>
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
        <h4>Total Pendaftar</h4>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-striped table-bordered">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Nama</th>
                <th scope="col">Progress</th>
                <th scope="col">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                <td><?php echo e($siswa->nama); ?></td>
                <td>
                  <div class="progress" data-height="4" data-toggle="tooltip" title="" data-original-title="100%"
                    style="height: 4px;">
                    <?php if($siswa->status == 2): ?>
                    <div class="progress-bar bg-success" data-width="100%" style="width: 100%"></div>
                    <?php else: ?>
                    <div class="progress-bar bg-success" data-width="50%" style="width: 50%"></div>
                    <?php endif; ?>
                  </div>
                </td>
                <td><a href="/admin/detail/siswa/<?php echo e($siswa->id); ?>"
                    class="btn btn-warning mr-2 mb-2">Detail</a></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/fernando/Sites/richard/resources/views/pages/admin/index.blade.php ENDPATH**/ ?>