<footer class="bg-primary py-4 fixed-bottom" style="">
  <div class="container-lg">
      <div class="col-md-4 mb-4 text-center text-md-left">
        <p class="text-light">&copy; 2025 SMA Swasta Mariana. Semua hak cipta dilindungi.</p>
      </div>
  </div>
</footer>

<!-- Tambahkan Font Awesome CDN untuk icon sosial media -->
<script src="https://kit.fontawesome.com/a076d05399.js"></script><?php /**PATH /Users/fernando/Sites/richard/resources/views/layouts/components/guest/_footer.blade.php ENDPATH**/ ?>