<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Dashboard PPDB SMA SWASTA KATOLIK MARIANA</title>
  <link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/css/all.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/css/components.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap-datepicker.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/css/admin.css')); ?>">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
    integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
</head>

<body>

  <div id="app" class="">
    <div class="main-wrapper">
      <div class="navbar-bg"></div>
      <nav class="navbar navbar-expand-lg main-navbar">
        <form class="form-inline mr-auto">
          <ul class="navbar-nav mr-3">
            <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
          </ul>
        </form>
        <ul class="navbar-nav navbar-right">
          <li class="dropdown"><a href="#" data-toggle="dropdown"
              class="nav-link dropdown-toggle nav-link-lg nav-link-user">
              <i class="fas fa-user mr-2"></i>
              <div class="d-sm-none d-lg-inline-block">Hi, Admin</div>
            </a>
            <div class="dropdown-menu dropdown-menu-right">
              <a href="<?php echo e(route('logout')); ?>" class="dropdown-item has-icon text-danger">
                <i class="fas fa-sign-out-alt"></i> Logout
              </a>
            </div>
          </li>
        </ul>
      </nav>
      <div class="main-sidebar">
        <aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <a href="/admin">ADMIN PPDB</a>
          </div>
          <ul class="sidebar-menu">
            <li class="menu-header">GRAFIK</li>
            <li class="<?php echo $__env->yieldContent('nav__item-admin'); ?>">
              <a class="nav-link" href="<?php echo e(route('admin')); ?>">
                <i class="fas fa-home"></i>
                <span>Dashboard</span>
              </a>
            </li>
            <li class="menu-header">MAIN</li>
            <li class="<?php echo $__env->yieldContent('nav__item-admin-pengumuman'); ?>">
              <a class="nav-link" href="<?php echo e(route('admin.pengumuman')); ?>">
                <i class="fas fa-bullhorn"></i>
                <span>Pengumuman</span>
              </a>
            </li>
            <li class="<?php echo $__env->yieldContent('nav__item-admin-siswa'); ?>">
              <a class="nav-link" href="<?php echo e(route('admin.siswa')); ?>">
                <i class="fas fa-users"></i>
                <span>Data Pendaftar</span>
              </a>
            </li>
            <li class="<?php echo $__env->yieldContent('nav__item-admin-konfirmasi'); ?>">
              <a class="nav-link" href="/admin/konfirmasi">
                <i class="fas fa-key"></i>
                <span>Konfirmasi</span>
              </a>
            </li>
            <li class="<?php echo $__env->yieldContent('nav__item-admin-galeri'); ?>">
              <a class="nav-link" href="/admin/galeri">
                <i class="fas fa-images"></i>
                <span>Geleri</span>
              </a>
            </li>
          </ul>
        </aside>
      </div>

      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-header">
            <h1><?php echo $__env->yieldContent('title'); ?></h1>
          </div>
          <div class="section-body">
            <?php echo $__env->yieldContent('content'); ?>
          </div>
        </section>
      </div>
      <footer class="main-footer">
        <div class="footer-left">
          Jurnal - SMA SWASTA KATOLIK MARIANA
        </div>
      </footer>
    </div>
  </div>

  <?php echo $__env->yieldContent('modal'); ?>

  <script src="<?php echo e(asset('/js/jquery-3.3.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/popper.min.js')); ?>">
  </script>
  <script src="<?php echo e(asset('/js/bootstrap.min.js')); ?>">
  </script>
  <script src="<?php echo e(asset('/js/jquery.nicescroll.min.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/moment.min.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/stisla.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/scripts.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/custom.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/dataTables.bootstrap4.min.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/bootstrap-datepicker.min.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/bootstrap-multiselect.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/chart.js')); ?>"></script>
  <script>
    $(document).ready(function(){
        $('.data').DataTable();

        $(".datepicker").datepicker({
                format: "yyyy-mm-dd",
                autoclose: true,
                todayHighlight: true,
                orientation: "bottom auto"
        });

        $('.multi-select').multiselect({
            enableClickableOptGroups: true,
            enableCollapsibleOptGroups: true,
            enableFiltering: true,
            includeSelectAllOption: true
        });
    });
  </script>

  <?php echo $__env->yieldContent('script'); ?>
</body>

</html><?php /**PATH /Users/fernando/Sites/richard/resources/views/layouts/admin.blade.php ENDPATH**/ ?>