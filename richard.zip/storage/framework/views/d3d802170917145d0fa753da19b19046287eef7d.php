<?php $__env->startSection('nav__item-siswa-pengumuman', 'active'); ?>





<?php echo $__env->make('layouts.components.siswa._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.components.siswa._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('main'); ?>
<main>
  <div class="container-lg d-flex justify-content-center py-4">
    <div class="col-12 col-md-10 col-lg-8 p-0">
      <div class="row">
        <div class="col-12">
          <?php $__currentLoopData = $pengumuman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card mb-3">
            <div class="card-body">
              <h5 class="card-title border-bottom pb-2 mb-2"><?php echo e($data->judul); ?></h5>
              <p class="card-text"><?php echo e($data->deskripsi); ?></p>
              <div class="d-flex justify-content-between">
                <p class="card-text m-0"><small class="text-muted"><?php echo e(date_format($data->created_at, 'h:i')); ?></small>
                </p>
                <p class="card-text m-0"><small class="text-muted"><?php echo e(date_format($data->created_at, 'd-m-Y')); ?></small>
                </p>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php $__currentLoopData = $pesan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card mb-3">
            <div class="card-body">
              <h5 class="card-title border-bottom pb-2 mb-2"><?php echo e($data->judul); ?></h5>
              <p class="card-text"><?php echo e($data->isi); ?></p>
              <div class="d-flex justify-content-between">
                <p class="card-text m-0"><small class="text-muted"><?php echo e(date_format($data->created_at, 'h:i')); ?></small>
                </p>
                <p class="card-text m-0"><small class="text-muted"><?php echo e(date_format($data->created_at, 'd-m-Y')); ?></small>
                </p>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/fernando/Sites/richard/resources/views/pages/siswa/pengumuman.blade.php ENDPATH**/ ?>