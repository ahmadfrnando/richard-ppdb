<?php $__env->startSection('nav__item-masuk', 'active'); ?>
<?php $__env->startSection('nav__icon-masuk', 'opacity-100'); ?>





<?php echo $__env->make('layouts.components.app._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.components.app._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('main'); ?>
<main>
  <div class="container-lg py-4">
    <div class="row justify-content-center">
      <div class="col-12 col-lg-9 px-0 px-md-3 mb-4">
        <div class="mb-md-3 px-3 px-md-5 py-4 py-md-5 bg-primary shadow-sm">
          <h4 class="text-white mb-0">Masuk Akun PPDB</h4>
          <h4 class="text-white">SMA SWASTA KATOLIK MARIANA</h4>
          <h6 class="text-white font-weight-normal">TAHUN PELAJARAN 2024/2025</h6>
        </div>

        <?php if(session('error')): ?>
        <div class="alert alert-danger mt-3" role="alert">
          <?php echo e(session('error')); ?>

        </div>
        <?php endif; ?>

        <div class="mb-3 px-3 px-md-5 py-4 py-md-5 bg-light shadow-sm">
          <form action="<?php echo e(route('login.store')); ?>" method="post">
            <?php echo csrf_field(); ?>

            
            <div class="siswa__section mb-4">
              <div class="d-flex align-items-center pb-3">
                <span class="bg-primary mb-2 rounded-pill" style="height: 0.4rem; width: 1.6rem;"></span>
                <h5 class="ml-3">Data Akun</h5>
              </div>
              <div class="form-group row">
                <label for="username" class="col-sm-4 col-form-label font-weight-normal">NISN<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="text" class="form-control  <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="username"
                    name="username" autocomplete="off" required>
                  <small class="form-text text-muted">nb: <span class="text-dark">( Masukkan NISN yang valid saat
                      digunakan untuk pendaftaran )</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="password" class="col-sm-4 col-form-label font-weight-normal">PIN<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="text" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password"
                    name="password" autocomplete="off" required>
                  <small class="form-text text-muted">nb: <span class="text-dark">( Masukkan PIN yang terdapat pada
                      Bukti Pembayaran
                      )</span></small>
                </div>
              </div>
            </div>

            
            <div class="kirim__section">
              <div class="mb-4">
                <h6 class="font-weight-semibold">PERHATIAN :</h6>
                <small class="m-0 d-block">- Isian dengan tanda (<span class="text-danger">*</span>) adalah wajib
                  diisi.</small>
                <small class="m-0 d-block">- Silahkan cek kembali seluruh data yang sudah diisi.</small>
                <small class="m-0 d-block">- Dengan mengirim data ini, saya menyatakan sudah mengisi data dengan
                  benar dan
                  lengkap.</small>
              </div>
              <button class="btn btn-success py-2 w-100">Lanjutkan Masuk</button>
            </div>
          </form>
        </div>
      </div>

      <?php echo $__env->make('layouts.components.app._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/fernando/Sites/richard/resources/views//pages/masuk.blade.php ENDPATH**/ ?>