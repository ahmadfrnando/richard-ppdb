<?php $__env->startSection('nav__item-konfirmasi', 'active'); ?>
<?php $__env->startSection('nav__icon-konfirmasi', 'opacity-100'); ?>





<?php echo $__env->make('layouts.components.app._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.components.app._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('main'); ?>
<main>
  <div class="container-lg py-4">
    <div class="row justify-content-center">
      <div class="col-12 col-lg-9 px-0 px-md-3 mb-4">
        <div class="mb-md-3 px-3 px-md-5 py-4 py-md-5 bg-primary shadow-sm">
          <h4 class="text-white mb-0">Konfirmasi Pembayaran PPDB</h4>
          <h4 class="text-white">SMA SWASTA KATOLIK MARIANA</h4>
          <h6 class="text-white font-weight-normal">TAHUN PELAJARAN 2024/2025</h6>
        </div>
        <div class="mb-3 px-3 px-md-5 py-4 py-md-5 bg-light shadow-sm">
          <form action="<?php echo e(route('konfirmasi.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            
            <div class="siswa__section mb-4">
              <div class="d-flex align-items-center pb-3">
                <span class="bg-primary mb-2 rounded-pill" style="height: 0.4rem; width: 1.6rem;"></span>
                <h5 class="ml-3">Data Konfirmasi</h5>
              </div>
              <div class="form-group row">
                <label for="nama" class="col-sm-4 col-form-label font-weight-normal">Nama Pendaftar<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama" name="nama"
                    autocomplete="off" required>
                  <small class="form-text text-muted">ex: <span class="text-dark">Rigen
                      Maulana</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="nisn" class="col-sm-4 col-form-label font-weight-normal">NISN<span
                    class="text-danger">*</span> </label>
                <div class="col-sm-8">
                  <input type="text" class="form-control <?php $__errorArgs = ['nisn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nisn" name="nisn"
                    autocomplete="off" required>
                  <small class="form-text text-muted">nb: <span class="text-dark">( Masukkan NISN yang valid saat
                      digunakan untuk pendaftaran )</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="nomer_hp" class="col-sm-4 col-form-label font-weight-normal">Nomer HP ( Whatsapp )<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="text" class="form-control <?php $__errorArgs = ['nomer_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nomer_hp"
                    name="nomer_hp" autocomplete="off" required>
                  <small class="form-text text-muted">ex: <span class="text-dark">08123456789 , nb: (Untuk mengirim
                      status konfirmasi pembayaran)</span></small>
                </div>
              </div>
              <div class="form-group row">
                <label for="bukti_pembayaran" class="col-sm-4 col-form-label font-weight-normal">Bukti Pembayaran<span
                    class="text-danger">*</span></label>
                <div class="col-sm-8">
                  <input type="file" class="form-control-file <?php $__errorArgs = ['bukti_pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="bukti_pembayaran" name="bukti_pembayaran" accept="image/png, image/jpeg, image/jpg"
                    autocomplete="off" required>
                  <small class="form-text text-muted">nb: <span class="text-dark">(Gambar dengan format .jpg, .jpeg,
                      .png)</span></small>
                </div>
              </div>
            </div>

            
            <div class="kirim__section">
              <div class="mb-4">
                <h6 class="font-weight-semibold">PERHATIAN :</h6>
                <small class="m-0 d-block">- Isian dengan tanda (<span class="text-danger">*</span>) adalah wajib
                  diisi.</small>
                <small class="m-0 d-block">- Silahkan cek kembali seluruh data yang sudah diisi.</small>
                <small class="m-0 d-block">- Dengan mengirim data ini, saya menyatakan sudah mengisi data dengan
                  benar dan
                  lengkap.</small>
              </div>
              <button class="btn btn-success py-2 w-100">Konfirmasi Pembayaran</button>
            </div>
          </form>
        </div>
      </div>

      <?php echo $__env->make('layouts.components.app._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/fernando/Sites/richard/resources/views//pages/konfirmasi.blade.php ENDPATH**/ ?>