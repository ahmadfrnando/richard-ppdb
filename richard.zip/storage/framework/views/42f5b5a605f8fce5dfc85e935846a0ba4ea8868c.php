<?php echo $__env->make('layouts.components.app._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.components.app._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('main'); ?>
<main>
  <div class="container-lg py-4">
    <div class="row justify-content-center">
      <div class="col-12 col-lg-9 px-0 px-md-3 mb-4">

        <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
          Pendaftaran PPDB telah berhasil ...
        </div>
        <?php endif; ?>

        <?php if(session()->get('id_siswa') == null): ?>

        <div class="mb-3 px-3 px-md-5 py-4 py-md-5 bg-light shadow-sm">
          <div class="mb-4">
            <h4 class="text-danger">NISN tidak terdaftar</h4>
            <h6 class="text-danger">Silahkan melakukan Pendaftaran terlebih dahulu 🔥</h6>
          </div>
          <div class="kirim__section">
            <div class="mb-4">
              <h6 class="font-weight-semibold">PERHATIAN :</h6>
              <small class="m-0 d-block">- Cek Pendaftaran dengan memasukkan
                NISN yang valid.</small>
              <small class="m-0 d-block">- Silahkan lakukan pendaftaran jika belum mendaftar.</small>
            </div>
            <a href="/pendaftaran" class="btn btn-primary py-2 w-100 mb-2">Mulai Pendaftaran</a>
          </div>
        </div>

        <?php else: ?>

        <div class="mb-3 px-3 px-md-5 py-4 py-md-5 bg-light shadow-sm">
          <div class="mb-4">
            <h4 class="text-success">Terima kasih telah mendaftar ✨</h4>
            <h6 class="text-success">PPDB SMA SWASTA KATOLIK MARIANA</h6>
            <div class="row mt-4">
              <div class="col-12 col-md-6">
                <div class="">
                  <label class="mb-0">NISN: </label>
                  <p class="font-weight-medium"><?php echo e($siswa->nisn); ?></p>
                </div>
                <div class="">
                  <label class="mb-0">Nama: </label>
                  <p class="font-weight-medium"><?php echo e($siswa->nama); ?></p>
                </div>
              </div>
              <div class="col-12 col-md-6">
                <div class="">
                  <label class="mb-0">Jurusan: </label>
                  <p class="font-weight-medium"><?php echo e($siswa->jurusan); ?></p>
                </div>
              </div>
            </div>
          </div>
          <div class="kirim__section">
            <div class="mb-4">
              <h6 class="font-weight-semibold">PERHATIAN :</h6>
              <small class="m-0 d-block">- Cek apakah data sudah benar.</small>
              <small class="m-0 d-block">- Silahkan unduh bukti pendaftaran dengan klik tombol dibawah.</small>
              <small class="m-0 d-block">- Silahkan cek nisn dan pin pada bukti pendaftaran, untuk dapat login ker portal PPDB.</small>
            </div>
            <a href="/detail/bukti-pendaftaran/<?php echo e($siswa->id); ?>" class="btn btn-success py-2 w-100 mb-2">Unduh Bukti Pendaftaran</a>
            <a href="/masuk" class="btn btn-primary py-2 w-100 mb-2">Masuk</a>
          </div>
        </div>

        <?php endif; ?>

      </div>

      <?php echo $__env->make('layouts.components.app._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/fernando/Sites/richard/resources/views//pages/detail.blade.php ENDPATH**/ ?>